const Orders = () => {
    return (
        <div>
            <h1>Your Orders</h1>
        </div>
    );
};

export default Orders;
